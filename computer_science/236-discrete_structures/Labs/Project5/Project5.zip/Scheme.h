//#ifndef SCHEME_H_
//#define SCHEME_H_

#include<string>
#include<vector>

using std::vector;
using std::string;

class Scheme : public vector < string >
{
public:
	//vector <string> Names;
	Scheme(){};	
//	Scheme(vector<string> list) : Names(list) {}
};

//#endif