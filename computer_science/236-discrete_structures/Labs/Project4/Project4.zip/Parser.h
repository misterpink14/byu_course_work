#include "DatalogProgram.h"



class Parser
{
	//DatalogProgram Prog;
	//Rule R;
	//Predicate Pred;
	//Parameter Param;

public:

	void Parse(vector<Token> &tList);

};