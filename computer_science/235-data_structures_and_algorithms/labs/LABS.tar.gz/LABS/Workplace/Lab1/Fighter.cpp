/*
 * Fighter.cpp
 *
 *  Created on: May 8, 2014
 *      Author: misterpink14
 */

#include "Fighter.h"


	Fighter::Fighter(string n, int maxhp, int st, int sp, int mag)
	{
		name = n;
		hp = maxhp;
		str = st;
		speed = sp;
		magic = mag;
		currentHp = maxhp;
	}



	 string Fighter::getName()
	{
		return name;
	}


	 int Fighter::getMaximumHP()
	{
		return hp;
	}


	 int Fighter::getCurrentHP()
	{
		return currentHp;
	}


	 int Fighter::getStrength()
	{
		return str;
	}


	  int Fighter::getSpeed()
	{
		return speed;
	}


	 int Fighter::getMagic()
	{
		return magic;
	}


	  void Fighter::takeDamage(int damage)
	{
		damage = damage - (speed / 4);
		if (damage < 1) { damage = 1; }
		currentHp = currentHp - damage;
	}


	  void Fighter::reset()
	{
		currentHp = hp;
	}


	  void Fighter::regenerate()
	{
		int regen = str / 6;
		if(regen > 0)
		{
			currentHp += regen;
			if (currentHp > hp)
				currentHp = hp;
		}
		else
		{
			currentHp++;
			if(currentHp > hp)
				currentHp = hp;
		}
	}
