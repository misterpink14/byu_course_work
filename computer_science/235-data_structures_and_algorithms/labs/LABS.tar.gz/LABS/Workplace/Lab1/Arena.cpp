/*
 * Arena.cpp
 *
 *  Created on: May 8, 2014
 *      Author: misterpink14
 */
#include "Arena.h"
#include <cstdlib>
#include <iostream>


	bool Arena::addFighter(string info)
	{
		stringstream ss(info);
		string name, type;
		int maxHp, sp, st, mag;

		if (ss >> name >> type >> maxHp >> st >> sp >> mag)
		{
			if((type == "A") || (type == "R") || (type == "C"))
			{
			if (maxHp < 1 || st < 1 || sp < 1 || mag < 1)
				return false;
			if(!ss.eof())
				return false;
			for(unsigned int i = 0; i < Colosseum.size(); i++)
			{
				if(Colosseum[i]->getName() == name)
					return false;
			}
			if(type == "A")
            {
                FighterInterface* a = new Archer(name, maxHp, st, sp, mag);
				Colosseum.push_back(a);
            }
			else if(type == "R")
            {
                FighterInterface* r = new Robot(name, maxHp, st, sp, mag);
				Colosseum.push_back(r);
            }
			else// if(type == "C")
			{
                FighterInterface* c = new Cleric(name, maxHp, st, sp, mag);
				Colosseum.push_back(c);
			}
			return true;
			}
			else {return false;}
		}
        else {return false; }

	}

	/*
	 *	removeFighter(string)
	 *
	 *	Removes the fighter whose name is equal to the given name.  Does nothing if
	 *	no fighter is found with the given name.
	 *
	 *	Return true if a fighter is removed; false otherwise.
	 */
	bool Arena::removeFighter(string name)
	{
	//	if(!Colosseum.empty())
	//	{
			//find the name of the fighter and erase
			// return true
			for(vector<FighterInterface*>::iterator a = Colosseum.begin(); a!=Colosseum.end(); a++)
			{
				if ((*a)->getName() == name)
				{
					Colosseum.erase(a);
					return true;
				}
			}
	//	}
		return false;
	}

	/*
	 *	getFighter(string)
	 *
	 *	Returns the memory address of a fighter whose name is equal to the given
	 *	name.  Returns NULL if no fighter is found with the given name.
	 *
	 *	Return a memory address if a fighter is found; NULL otherwise.
	 */
	FighterInterface* Arena::getFighter(string name)
	{
		// look for fighter"s name, return Colosseum[i]
		for (unsigned int i = 0; i < Colosseum.size(); i++)
		{
			if (Colosseum[i]->getName() == name)
				return Colosseum[i];
		}
		return NULL;
	}

	/*
	 *	getSize()
	 *
	 *	Returns the number of fighters in the arena.
	 *
	 *	Return a non-negative integer.
	 */
	 int Arena::getSize()
	{
		return Colosseum.size();
	}
