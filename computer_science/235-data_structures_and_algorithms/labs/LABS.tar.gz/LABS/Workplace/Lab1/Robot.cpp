/*
 * Robot.cpp
 *
 *  Created on: May 8, 2014
 *      Author: misterpink14
 */


#include "Robot.h"

	Robot::Robot(string n, int maxhp, int st, int sp, int mag) : Fighter::Fighter(n, maxhp, st, sp, mag),
		power(mag * 2),
		currentPower(mag *2),
		bonusDmg(0)
	{}


//	~Robot()
	//regenerate()
	int Robot::getDamage()
	{
		return (str + bonusDmg);
	}


	void Robot::reset()
	{
		Fighter::reset();
		currentPower = power;
		bonusDmg = 0;
	}

	bool Robot::useAbility()
	{
		if(ROBOT_ABILITY_COST <= currentPower)
		{
			bonusDmg = str * (pow(((double)currentPower/(double)power), 4));
			currentPower -= ROBOT_ABILITY_COST;
			return true;
		}
		bonusDmg = 0;
		return false;
	}
