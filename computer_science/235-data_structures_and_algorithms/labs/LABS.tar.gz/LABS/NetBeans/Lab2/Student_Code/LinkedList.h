#include <string>
#include <iostream>
#include "LinkedListInterface.h"

using namespace std;

#pragma once
template < class T >
class LinkedList :
		public LinkedListInterface<T>
{

private:
	struct Node
	{
		T item;
		Node* next;

		Node()
		{
			//item = NULL;
			next = NULL;
		};
		~Node() { next = NULL; }
		Node(T value, Node* n = NULL)
		{
			item = value;
			next = n;
		};
	};
	Node* head;

	int amt;

public:

	LinkedList()
	{
		head = NULL;
	//	tail = NULL;
		amt = 0;
	};

	~LinkedList()
	{
	    clear();
	}

	/*
		insertHead

		A node with the given value should be inserted at the beginning of the list.

		Do not allow duplicate values in the list.
	 */
	void insertHead(T value)
	{
		if(head == NULL)
		{
		    Node* n = new Node(value);
			head = n;
			amt++;
			return;
		}
		else if(head->item == value)
		{
			return;
		}
		else
		{
			Node* n = head;
			while(n!= NULL)
			{
				
				if(n->item == value)
				{
					return;
				}
				n = n->next;
			}

		//check to see if it is in the LL

		Node* h = new Node(value, head);
		head = h;
		amt++;
		return;
		}
	}

	/*
		insertTail

		A node with the given value should be inserted at the end of the list.

		Do not allow duplicate values in the list.
	 */
	void insertTail(T value)
	{
		if(head == NULL)
		{
		    Node* n = new Node (value);
			head = n;
		//	tail = n;
			amt++;
			return;
		}
		Node* n = head;
		while(n->next != NULL)
		{
			if(n->item == value)
			{
				return;
			}
			if(n->next != NULL)
				n = n->next;
		}
		if(n->item == value)
		{
			return;
		}
		//check to see if is it in LL
		Node* h = new Node(value);
		n->next = h;
	//	tail = n->next;
		amt++;
	}

	/*
		insertAfter

		A node with the given value should be inserted immediately after the
		node whose value is equal to insertionNode.

		A node should only be added if the node whose value is equal to
		insertionNode is in the list. Do not allow duplicate values in the list.
	 */
	void insertAfter(T value, T insertionNode)
	{
		if (head == NULL)
		{
			return;
		}

		Node* h = head;
		while (h != NULL)
		{
			if(h->item == value)
			{
				return;
			}
			h = h->next;
		}

		Node *n = head;
		while(n!=NULL)// && n->item != insertionNode)
		{	// while the next value is not NULL
			if (n->item == insertionNode)
			{	// if the item == the insertion value, exit the loop
				break;
			}
			n = n->next;	// move to the next value
		}
		if(n == NULL)
		    return;
		else
		{
		    Node *h = new Node(value, n->next);
		    n->next = h;
		    amt++;
		}
	}
	
	/*
		remove

		The node with the given value should be removed from the list.

		The list may or may not include a node with the given value.
	 */
	void remove(T value)
	{	///THIS NEEDS FIXEDDDDDDD
		if (head == NULL)
		{
		    return;
		}
		else if(head->item == value)
		{
			Node* n = head;
			head = head->next;
			delete n;
			amt--;
			return;
		}
		Node*n = head;
		while(n->next != NULL)
		{
			if(n->next->item == value)
			{
				Node* h = n->next;
				n->next = h->next;
				delete h;
				amt--;
				return;
			}
			n = n->next;
		}
	}

	/*
		clear

		Remove all nodes from the list.
	 */
	 void clear()
	{
		Node* n = head;
 		while(n!=NULL)
 		{
 			head = head->next;
 			delete n;
 			n = head;
 		}
 		amt = 0;
	}

	/*
		at

		Returns the value of the node at the given index. The list begins at
		index 0.

		If the given index is out of range of the list, return NULL;
	 */
	T at(int index)
	{
		Node *n = head;
	    for (int i = 0; i < amt; i++)
	    {
		if (i == index)
			return n->item;
		else
		    n = n->next;
		
	    }   
	    return NULL;
	}
	

	/*
		size

		Returns the number of nodes in the list.
	 */
	int size()
	{
		return amt;
	}

};
