/* 
 * File:   Deque.h
 * Author: misterpink14
 *
 * Created on May 22, 2014, 9:46 PM
 */

#ifndef DEQUE_H
#define	DEQUE_H



#endif	/* DEQUE_H */

