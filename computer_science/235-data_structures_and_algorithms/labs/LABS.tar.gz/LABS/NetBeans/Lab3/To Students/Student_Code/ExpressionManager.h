#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <iostream>
#include <stack>
#include "ExpressionManagerInterface.h"

using namespace std;

class ExpressionManager :
public ExpressionManagerInterface {
private:
    int bracket; //[]
    int brace; //{}
    int parenth; //()
    stack<char> flag;
    
    
    bool isSym(string c)
    {
	if(c == "{" || c == "}" || c == "[" || c == "]" )//|| 
//	    c == "+" || c == "-" || c == "*" || c == "/" || c == "%")
	{
	    return true;
	}
	return false;
    }
    
    bool isInt(string c)
    {
	stringstream ss(c);
	int i; 
	if(ss >> i)
    	{
	    if(ss.peek() == '.')
	    {
		return false;
	    }
	    return true;
	}
	if (ss.fail())
	{
	    ss.clear();
	}
	return false;
    }
    
    bool isInt(char c)
    {
	stringstream ss;
	ss << c;
	int i; 
	if(ss >> i)
    	{
	    return true;
	}
	if (ss.fail())
	{
	    ss.clear();
	}
	return false;
    }
    
    bool isParenth(string c)
    {
	if(c == ")\0" || c == ") " || c == " )")
	{
	    return true;
	}
	return false;
    }
    
    bool isParenth(char c)
    {
	if(c == ')')
	{
	    return true;
	}
	return false;
    }
    
    bool isOParenth(string c)
    {
	if(c == "(" || c == "(\0" || c == "( " || c == " (")
	{
	    return true;
	}
	return false;
    }
    
    bool isHigher(string c)
    {
	if(c == "*" || c == "/" || c == "%" || c == "*\0" || c == "/\0" || c == "%\0" ||
		c == "* " || c == "/ " || c == "% " || c == " *" || c == " /" || c == " %" )
	{
	    return true;
	}
	else
	return false;
    }
    
    bool isLower(string c)
    {
	if(c == "+" || c == "-")
	{
	    return true;
	}
	return false;
    }
    
    int operate(int l, int r, string sol)
    {
//	stringstream ss;
//	int l, r;
//	
//	ss << left;
//	if(ss >> l)
//	{
//	    ss.str("");
//	    ss << right;
//	}
//	else
//	{
//	    cout << " invalid left ";
//	    ss.clear();
//	    return -1;
//	}
//	ss >> r;
//	if (ss.fail())
//	{
//	    cout << " invalid right ";
//	    ss.clear();
//	    return -1;
//	}
	
	if (sol ==  "*" || sol == "*\0" || sol ==  " *" || sol ==  "* ")
	{
		return l*r;
	}
	else if(sol ==  "/"|| sol ==  "/\0" ||sol ==  " /" || sol ==  "/ ")
	{
		if( r == 0 )
		    return 1000;
		return l/r;
	}
	else if(sol ==  "%"|| sol ==  "%\0" ||sol ==  " %" || sol ==  "% ")
	{
		if( r == 0 )
		    return 1000;
		return l%r;
	}
	else if(sol ==  "+"|| sol ==  "+\0" ||sol ==  " +" || sol ==  "+ ")
	{
	    return l+r;
	}
	else if(sol ==  "-"|| sol ==  "-\0" ||sol ==  " -" || sol ==  "- ")
	{
	    return l-r;
	}
	else
	{
		return 1000;
	}
    }
    

public:

    ExpressionManager() : bracket(0), brace(0), parenth(0) {
        flag.push('0');
    }

    ~ExpressionManager() {
    }

/*
     * Checks whether an expression is balanced on its parentheses
     *
     * - The given expression will have a space between every number or operator
     *
     * @return true if expression is balanced
     * @return false otherwise
     */

    bool isBalanced(string expression) {
        for (unsigned i = 0; i < expression.size(); i++) {
            if (bracket < 0 || brace < 0 || parenth < 0) {
                bracket = brace = parenth = 0;
                return false;
            } else {
                switch (expression[i]) {
                    case '[':
                        bracket++;
                        flag.push(']');
                        break;
                    case ']':
                        if (flag.top() != ']') {
                            bracket = brace = parenth = 0;
                            return false;
                        }
                        flag.pop();
                        bracket--;
                        break;
                    case '{':
                        brace++;
                        flag.push('}');
                        break;
                    case '}':
                        if (flag.top() != '}') {
                            bracket = brace = parenth = 0;
                            return false;
                        }
                        flag.pop();
                        brace--;
                        break;
                    case '(':
                        parenth++;
                        flag.push(')');
                        break;
                    case ')':
                        if (flag.top() != ')') {
                            bracket = brace = parenth = 0;
                            return false;
                        }
                        flag.pop();
                        parenth--;
                        break;
                    default:
                        break;
                }

            }


        }
        if (bracket != 0 || brace != 0 || parenth != 0) {
            bracket = brace = parenth = 0;
            return false;
        }
        bracket = brace = parenth = 0;
        return true;
    }

/**
     * Converts a postfix expression into an infix expression
     * and returns the infix expression.
     *
     * - The given postfix expression will have a space between every number or operator.
     * - The returned infix expression must have a space between every number or operator.
     * - Redundant parentheses are acceptable i.e. ( ( 3 * 4 ) + 5 ).
     * - Check lab requirements for what will be considered invalid.
     *
     * return the string "invalid" if postfixExpression is not a valid postfix expression.
     * otherwise, return the correct infix expression as a string.
     */
    string postfixToInfix(string postfixExpression) {
        stack<string> out;
        string left;
	string right;
	string sol;
	stringstream ss(postfixExpression);
	while(ss >> sol)
	{
	    if(isInt(sol) || isLower(sol) || isHigher(sol))
	    {
		if(!isInt(sol))
		{
		    if(out.empty())
		    {
			return "invalid";
		    }
		    else
		    {
			right = out.top();
			out.pop();
			if(out.empty())
			{
			    return "invalid";
			}
			left = out.top();
			if(!isInt(left[left.size()-1]) && !isParenth(left[left.size()-1]))
			{
			    return "invalid";
			}
			else
			{
			    if(out.empty())
			    {
				return "invalid";
			    }
			    
			    out.pop();
			    out.push("( " + left + " " + sol + " " + right + " )");
			}
		    }
		}
		else
		{
		    out.push(sol);
		}
	    }
	    else    // CHECK
	    {
		return "invalid";
	    }
	}
	sol = out.top();
	out.pop();
	if (out.empty())
	{
	    return sol;
	}
	else
	{
	    return "invalid";
	}
    }

/*
     * Converts an infix expression into a postfix expression
     * and returns the postfix expression
     *
     * - The given infix expression will have a space between every number or operator.
     * - The returned postfix expression must have a space between every number or operator.
     * - Check lab requirements for what will be considered invalid.
     *
     * return the string "invalid" if infixExpression is not a valid infix expression.
     * otherwise, return the correct postfix expression as a string.
     */
    string infixToPostfix(string infixExpression) 
    {
	stringstream ss(infixExpression);
	string c;
	string prev = "0";
	stack<string> out;
	stack<string> temp;
        if (isBalanced(infixExpression)) 
	{

	    while(ss >> c) 
	    {
		if (isParenth(c) && (isLower(prev) || isHigher(prev)))
		{
		    return "invalid";
		}
		else if((isLower(c) || isHigher(c)) && out.empty())
		{
		    return "invalid";
		}
		else if((isLower(c) || isHigher(c)) && (isLower(prev) || isHigher(prev)))
		{
		    return "invalid";
		}
		prev = c;
		
		
		if ( isInt(c))
		{
                    out.push(c);
                }
		else if (isOParenth(c))
		{
		    temp.push(c);
		}
		else if (isParenth(c))
		{
		    if(isOParenth(temp.top()))
		    {
			temp.pop();
		    }
		    else if(isHigher(temp.top()) || isLower(temp.top()))
		    {
			out.push(temp.top());
			temp.pop();
//			if(isOParenth(temp.top()))
//			{
////			//    out.push(temp.top());
//			    temp.pop();
//			}
//			temp.pop();
		    }
		    else
		    {
			return "invalid";
		    }
		}
		else if(isHigher(c))
		{
		    if(temp.empty())
		    {
			temp.push(c);
		    }
		    else if(isHigher(temp.top()))
		    {
			out.push(temp.top());
			temp.pop();
			temp.push(c);
		    }
		    else
		    {
			temp.push(c);
		    }
		}
		else if(isLower(c))
		{
		    if(temp.empty())
		    {
			temp.push(c);
		    }
		    else
		    {
			out.push(temp.top());
			temp.pop();
			temp.push(c);
		    }
		}
		else
		{
		    return "invalid";
		}
            }   
        }
	else
	{
            return "invalid";
        }
	while (!temp.empty())
	{
	    out.push(temp.top());
	    temp.pop();
	}
	stringstream ss2;
	while(!out.empty())
	{
	    if(out.size() == 1)
	    {
		temp.push(out.top());
		out.pop();
		break;
	    }
	    else if (isOParenth(out.top()))
	    {
		out.pop();
		continue;
	    }
	    temp.push(out.top());
	    temp.push(" ");
	    out.pop();
	}
	while(!temp.empty())
	{
	    ss2 << temp.top();
	    temp.pop();
	}
	return ss2.str();
    }

/*
     * Evaluates a postfix expression returns the result as a string
     *
     * - The given postfix expression will have a space between every number or operator.
     * - Check lab requirements for what will be considered invalid.
     *
     * return the string "invalid" if postfixExpression is not a valid postfix Expression
     * otherwise, return the correct evaluation as a string
     */
    string postfixEvaluate(string postfixExpression) {
        stack<int> out;
        int left;
	int right;
	string sol, temp;
	stringstream in;
	stringstream ss(postfixExpression);
	while(ss >> sol)
	{
	    if(isInt(sol) || isLower(sol) || isHigher(sol))
	    {
		if(!isInt(sol))
		{
		    if(out.empty())
		    {
			return "invalid";
		    }
		    else
		    {
			right = (int)out.top();
			out.pop();
			if(out.empty())
			{
			    return "invalid";
			}
			left = (int)out.top();
//			if(!isInt(left))
//			{
//			    cout << " invalid left " << left << " ";
//			    return "invalid";
//			}
//			else
//			{
			    if(out.empty())
			    {
				return "invalid";
			    }
			    
			    out.pop();
			    int i = operate(left, right, sol);
			    if (i == 1000)
			    {
				return "invalid";
			    }
			    out.push(i);
//			}
		    }
		}
		else
		{
		    stringstream s(sol);
		    int l;
		    s >> l;
		    out.push(l);
		}
	    }
	    else    // CHECK
	    {
		return "invalid";
	    }
	}
	in << out.top();
	out.pop();
	if (out.empty())
	{
	    return in.str();
	}
	else
	{
	    return "invalid";
	}
    }


};
