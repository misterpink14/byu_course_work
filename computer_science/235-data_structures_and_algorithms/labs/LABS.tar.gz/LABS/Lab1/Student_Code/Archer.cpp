/*
 * Archer.cpp
 *
 *  Created on: May 8, 2014
 *      Author: misterpink14
 */
#include "Archer.h"


	Archer::Archer(string n, int maxhp, int st, int sp, int mag) : Fighter::Fighter(n, maxhp, st, sp, mag),
		attackSp(sp) {}


	//~Archer();
	void Archer::regenerate()
	{
		Fighter::regenerate();
	}

	int Archer::getDamage()
	{
		return speed;
	}


	void Archer::reset()
	{
		Fighter::reset();
		speed = attackSp;
	}

	bool Archer::useAbility()
	{
		speed++;
		return true;
	}


