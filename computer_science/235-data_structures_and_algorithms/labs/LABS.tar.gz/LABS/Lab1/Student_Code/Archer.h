#ifndef ARCHER_H
#define ARCHER_H

#include "Fighter.h"

class Archer : public Fighter
{
public:
	Archer(string n, int maxhp, int st, int sp, int mag);


	~Archer(){}
	void regenerate();

	int getDamage();


	void reset();

	bool useAbility();

private:
	int attackSp;

};


#endif
