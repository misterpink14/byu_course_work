#ifndef CLERIC_H
#define CLERIC_H

#include "Fighter.h"

class Cleric : public Fighter
{
public:
	Cleric(string n, int maxhp, int st, int sp, int mag);

	~Cleric() {}
	void regenerate();


	int getDamage();


	void reset();

	bool useAbility();

private:
	int mana;
	int currentMana;

};


#endif
