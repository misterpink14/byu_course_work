/*
 * Cleric.cpp
 *
 *  Created on: May 8, 2014
 *      Author: misterpink14
 */
#include "Cleric.h"


	Cleric::Cleric(string n, int maxhp, int st, int sp, int mag) : Fighter::Fighter(n, maxhp, st, sp, mag),
		mana(mag * 5),
		currentMana(mag*5)
	{}


//	~Cleric();
	void Cleric::regenerate()
	{
		Fighter::regenerate();
		int five = magic/5;
		if(five >1)
		{
			currentMana += five;
		}
		else
		{
			currentMana++;
		}
		if(currentMana > mana)
			currentMana = mana;
	}



	int Cleric::getDamage()
	{
		return magic;
	}


	void Cleric::reset()
	{
		Fighter::reset();
		currentMana = mana;
	}

	bool Cleric::useAbility()
	{
		if(CLERIC_ABILITY_COST <= currentMana)
		{
			int increase = (magic/3);
			if(increase > 1)
			{
				currentHp += increase;
				if (currentHp > hp)
					currentHp = hp;
			}
			else
			{
				currentHp++;
				if (currentHp > hp)
					currentHp = hp;
			}
			currentMana -= CLERIC_ABILITY_COST;
			return true;
		}
		return false;
	}
