#ifndef ROBOT_H
#define ROBOT_H

#include "Fighter.h"
#include <math.h>

class Robot : public Fighter
{
public:
	Robot(string n, int maxhp, int st, int sp, int mag);


	~Robot() {}
	//regenerate()
	int getDamage();


	void reset();

	bool useAbility();

private:
	int power;
	int currentPower;
	int bonusDmg;
};

#endif
