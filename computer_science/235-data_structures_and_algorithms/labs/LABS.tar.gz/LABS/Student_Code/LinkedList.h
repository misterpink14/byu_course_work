#include <string>
#include "LinkedListInterface.h"

using namespace std;

#pragma once
template < class T >
class LinkedList :
		public LinkedListInterface<T>
{

private:
	struct Node
	{
		T item;
		Node* next;

		Node()
		{
			item = NULL;
			next = NULL;
		};
		~Node() {}
		Node(T value, Node* n = NULL)
		{
			item = value;
			next = n;
		};
	};
	Node* head;
	Node* tail;

	int amt;

public:

	LinkedList()
	{
		head = NULL;
		tail = NULL;
		amt = 0;
	};

	~LinkedList() {};

	/*
		insertHead

		A node with the given value should be inserted at the beginning of the list.

		Do not allow duplicate values in the list.
	 */
	void insertHead(T value)
	{
		if(head->item == value) { return; }
		if(head == NULL)
		{
			head = new Node(value);
		}
		Node* n = head;
		while(n->next != NULL)
		{
			n = n->next;
			if(n->item == value)
			{
				return;
			}
		}
		//check to see if it is in the LL


		head = new Node(value, head);
		amt++;
	}

	/*
		insertTail

		A node with the given value should be inserted at the end of the list.

		Do not allow duplicate values in the list.
	 */
	void insertTail(T value)
	{
		Node* n = head;
		while(n!=NULL)
		{
			if(n->item == value)
			{
				n = NULL;
				break;
			}
			n = n->next;
		}
		if(n != NULL)
			return;
		//check to see if is it in LL

		if(tail == NULL)
		{
			tail = new Node(value);
			head->next = tail;
		}
		else
		{
			tail->next = n;
			tail = n;
//			tail->next = NULL;
		}
		amt++;
	}


	/**Node* find(T value)
	{
		Node* n = head;
		while(n!=NULL)
		{
			if(n->item == value)
				return n;
			n = n->next;
		}
		return NULL;
	}**/

	/*
		insertAfter

		A node with the given value should be inserted immediately after the
		node whose value is equal to insertionNode.

		A node should only be added if the node whose value is equal to
		insertionNode is in the list. Do not allow duplicate values in the list.
	 */
	void insertAfter(T value, T insertionNode)
	{
		Node* n = head;
		while(n!=NULL)
		{
			if(n->item == value)
			{
				n = NULL;
				break;
			}
			n = n->next;
		}
		if(n != NULL)
			return;
		n = head;
		while(n!=NULL)
		{
			if(n->item == value)
			{
				n = NULL;
				break;
			}
			n = n->next;
		}
		if(n == NULL)
			return;
		Node* h = new Node(value);
		h->next = n;
		n->next = h;
	}
	
	/*
		remove

		The node with the given value should be removed from the list.

		The list may or may not include a node with the given value.
	 */
	void remove(T value)
	{	///THIS NEEDS FIXEDDDDDDD
		Node* h;
		Node* n = head;
		while(n!=NULL)
		{
			h = n;
			if(n->item == value)
			{
				n = NULL;
				break;
			}
			n = n->next;
		}
		if(n != NULL)
			return;
		if (n == NULL) {return;}
		h->next = n->next;
		delete n;
		amt--;
	}

	/*
		clear

		Remove all nodes from the list.
	 */
	 void clear()
	{
		Node* n = head->next;
		while(n!=NULL)
		{
			delete n;
		}
		delete head;
		amt = 0;
		head = NULL;
		tail = NULL;
	}

	/*
		at

		Returns the value of the node at the given index. The list begins at
		index 0.

		If the given index is out of range of the list, return NULL;
	 */
	T at(int index)
	{
		if (index > amt-1) { return NULL; }
		if (amt == 0) { return NULL; }
		Node* n = head;
		unsigned int i;
		for(i = 0; i < index; i++)
		{
			if(i == index)
				return n->item;
			else if (n->next == NULL)
				return NULL;
			n = n->next;
		}
		return NULL;
	}

	/*
		size

		Returns the number of nodes in the list.
	 */
	int size()
	{
		return amt;
	}

};
