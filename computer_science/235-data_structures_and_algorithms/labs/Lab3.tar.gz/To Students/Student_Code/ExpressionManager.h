#pragma once
#include <iostream>
#include <string>
#include <stack>
#include "ExpressionManagerInterface.h"

using namespace std;


class ExpressionManager :
		public ExpressionManagerInterface
{
	private:
		int bracket;//[]
		int brace;	//{}
		int parenth; //()
		stack<char> flag;

	public:
		ExpressionManager() : bracket(0), brace(0), parenth(0)
	{
			flag.push('0');
	}
		~ExpressionManager(){}

	/*
	* Checks whether an expression is balanced on its parentheses
	*
	* - The given expression will have a space between every number or operator
	*
	* @return true if expression is balanced
	* @return false otherwise
	*/

bool isBalanced(string expression)
{
	for(unsigned i = 0; i < expression.size(); i++)
	{
		if (bracket < 0 || brace < 0 || parenth < 0)
		{
			bracket = brace = parenth = 0;
			return false;
		}
		else
		{
			switch (expression[i])
			{
			case '[':
				bracket++;
				flag.push(']');
				break;
			case ']':
				if(flag.top() != ']')
				{
					bracket = brace = parenth = 0;
					return false;
				}
				flag.pop();
				bracket--;
				break;
			case '{':
				brace++;
				flag.push('}');
				break;
			case '}':
				if(flag.top() != '}')
				{
					bracket = brace = parenth = 0;
					return false;
				}
				flag.pop();
				brace--;
				break;
			case '(':
				parenth++;
				flag.push(')');
				break;
			case ')':
				if(flag.top() != ')')
				{
					bracket = brace = parenth = 0;
					return false;
				}
				flag.pop();
				parenth--;
				break;
			default:
				break;
			}

		}


	}
	if (bracket != 0 || brace != 0 || parenth != 0)
	{
		bracket = brace = parenth = 0;
				return false;
	}
	bracket = brace = parenth = 0;
	return true;
}

	/**
	 * Converts a postfix expression into an infix expression
	 * and returns the infix expression.
	 *
	 * - The given postfix expression will have a space between every number or operator.
	 * - The returned infix expression must have a space between every number or operator.
	 * - Redundant parentheses are acceptable i.e. ( ( 3 * 4 ) + 5 ).
	 * - Check lab requirements for what will be considered invalid.
	 *
	 * return the string "invalid" if postfixExpression is not a valid postfix expression.
	 * otherwise, return the correct infix expression as a string.
	 */
string postfixToInfix(string postfixExpression)
{
	stack<int> right;
	stack<int> left;
	for(unsigned i = 0; i < postfixExpression.size(); i += 2)
	{
		postfixExpression[i];

	}


	return "invalid";


}

	/*
	 * Converts an infix expression into a postfix expression
	 * and returns the postfix expression
	 *
	 * - The given infix expression will have a space between every number or operator.
	 * - The returned postfix expression must have a space between every number or operator.
	 * - Check lab requirements for what will be considered invalid.
	 *
	 * return the string "invalid" if infixExpression is not a valid infix expression.
	 * otherwise, return the correct postfix expression as a string.
	 */
string infixToPostfix(string infixExpression)
{
    cout << infixExpression;
	if(isBalanced(infixExpression))
	{
		for(unsigned i = 0; i < infixExpression.size(); i++)
		{
			if (infixExpression[i] != '{' || infixExpression[i] != '}' || infixExpression[i] != '[' ||
					infixExpression[i] != ']' || infixExpression[i] != '(' || infixExpression[i] != ')' ||
					infixExpression[i] != '+' || infixExpression[i] != '-' || infixExpression[i] != '*' ||
					infixExpression[i] != '/' || infixExpression[i] != '%' || infixExpression[i] != '1' ||
					infixExpression[i] != '2' || infixExpression[i] != '3' || infixExpression[i] != '4' ||
					infixExpression[i] != '5' || infixExpression[i] != '6' || infixExpression[i] != '7' ||
					infixExpression[i] != '8' || infixExpression[i] != '9' || infixExpression[i] != '0' ||
					infixExpression[i] != ' ')
			{
				return "invalid";
			}
			
		}
		return "yo momma";
	}
	else
	{
		return "invalid";
	}
}

	/*
	 * Evaluates a postfix expression returns the result as a string
	 *
	 * - The given postfix expression will have a space between every number or operator.
	 * - Check lab requirements for what will be considered invalid.
	 *
	 * return the string "invalid" if postfixExpression is not a valid postfix Expression
	 * otherwise, return the correct evaluation as a string
	 */
string postfixEvaluate(string postfixExpression)
{
    cout << postfixExpression;
	return 0;
}


};
