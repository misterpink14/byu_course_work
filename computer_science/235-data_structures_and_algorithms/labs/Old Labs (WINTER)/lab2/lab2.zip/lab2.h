// data types
#include <set>
#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <list>
// tolower
#include <cctype>
// input file
#include <fstream>
// 
#include <algorithm>
// spellcheck file/manip it
#include <sstream>
#include <iomanip>
//

