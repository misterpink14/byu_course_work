#pragma once
#include "Fighter.h"

class Cleric : public Fighter
{
public:
	Cleric(string n, int maxhp, int st, int sp, int mag) : Fighter(n, maxhp, st, sp, mag)
	{

		mana = mag * 5;
		currentMana = mana;
	}


	~Cleric();
	void regenerate()
	{
		Fighter::regenerate();
		if((magic/5) >1)
		{
			currentMana += (magic/5);
			if(currentMana > mana)
				currentMana = mana;
		}
		else
		{
			currentMana++;
			if (currentMana > mana)
				currentMana = mana;
		}
	}



	int getDamage()
	{
		return magic;
	}


	void reset()
	{
		Fighter::reset();
		currentMana = mana;
	}

	bool useAbility()
	{
		if(CLERIC_ABILITY_COST <= currentMana)
		{
			if(magic/3 > 1)
			{
				currentHp += magic/3;
				if (currentHp > hp)
					currentHp = hp;
			}
			else
			{
				currentHp++;
				if (currentHp > hp)
					currentHp = hp;
			}
			return true;
		}
		return false;
	}

private:
	int mana;
	int currentMana;

};
