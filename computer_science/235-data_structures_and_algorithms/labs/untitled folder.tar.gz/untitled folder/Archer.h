#pragma once
#include "Fighter.h"

class Archer : public Fighter
{
public:
	Archer(string n, int maxhp, int st, int sp, int mag) : Fighter(n, maxhp, st, sp, mag)
	{
		attackSp = sp;
	}


	~Archer();
//	void regenerate()

	int getDamage()
	{
		return speed;
	}


	void reset()
	{
		Fighter::reset();
		speed = attackSp;
	}

	bool useAbility()
	{
		speed++;
		return true;
	}

private:
	int attackSp;

};
