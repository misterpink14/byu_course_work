#pragma once
#include "Fighter.h"
#include <math.h>

class Robot : public Fighter
{
public:
	Robot(string n, int maxhp, int st, int sp, int mag) : Fighter(n, maxhp, st, sp, mag)
	{

		power = mag * 2;
		bonusDmg = 0;
	}


	~Robot();
	//regenerate()
	int getDamage()
	{
		return str + bonusDmg;
	}


	void reset()
	{
		Fighter::reset();
		currentPower = power;
		bonusDmg = 0;
	}

	bool useAbility()
	{
		if(ROBOT_ABILITY_COST <= currentPower)
		{
			bonusDmg = str * (pow((double)currentPower/(double)power, 4));
			currentPower -= ROBOT_ABILITY_COST;
			return true;
		}
		bonusDmg = 0;
		return false;
	}

private:
	int power;
	int currentPower;
	int bonusDmg;
};
